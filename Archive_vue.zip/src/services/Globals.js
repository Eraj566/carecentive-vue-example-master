const Globals = {
    SERVER_URL: "http://localhost:3001/api"
}

export default Globals;