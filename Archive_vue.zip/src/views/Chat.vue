<script setup>
import { ref } from "@vue/reactivity";
import { inject, onMounted } from "vue";
import axios from "axios";
import Globals from "/src/services/Globals";
import Message from "./Message.vue";
const AuthenticationService = inject("AuthenticationService");

const tickets = ref([]);
const chatMessages = ref([]);
const title = ref("");
const description = ref("");
const newMessage = ref("");
const role = ref();
const ticketList = ref([]);
const selectedTicket = ref(0);

// console.log(AuthenticationService.userData.user_id, "AuthenticationService")

const { user_id } = AuthenticationService.userData;

// Setup Socket.IO connection
import { io } from "socket.io-client";

const socket = io("http://localhost:3001"); // Replace with your Socket.IO server address

onMounted(async () => {
  try {
    // const userRole = AuthenticationService.getRoles(user_id);
    const rolesResponse = await axios.get(
      Globals.SERVER_URL + `/roles/${user_id}`
    );
    role.value = rolesResponse.data[0]?.id;

    if (role.value == 1) {
      const ticketResponse = await axios.get(
        Globals.SERVER_URL + `/tickets/${user_id}`
      );
      tickets.value = ticketResponse.data;

      getChat(ticketResponse.data[0]?.id);
    } else if (role.value == 2) {
      const ticketListResponse = await axios.get(
        Globals.SERVER_URL + `/tickets/open`
      );
      ticketList.value = ticketListResponse.data;
    } else {
    }

    socket.on("chatMessage", (message) => {
      if (message.ticket_id == selectedTicket.value) {
        
        chatMessages.value.push({
          message: message.text,
        });
      }
    });

    // Assuming you have a similar endpoint for chat messages
    // const chatResponse = await axios.get(Globals.SERVER_URL + `/chat/${user_id}`);
    // chatMessages.value = chatResponse.data;
  } catch (error) {
    console.error(error);
  }
});

async function insertTicket() {
  try {
    const response = await axios.post(Globals.SERVER_URL + `/tickets`, {
      id: user_id,
      title: title.value,
      description: description.value,
    });

    tickets.value.push({
      title: title.value,
      description: description.value,
    });
  } catch (error) {
    console.error(error);
  }
}

async function getChat(id) {
  try {
    selectedTicket.value = id;
    const response = await axios.get(Globals.SERVER_URL + `/chat/${id}`);
    
    chatMessages.value = JSON.parse(JSON.stringify(response.data));
    console.log([...chatMessages.value],response.data, "chatMessages.value");
  } catch (error) {
    console.error(error);
  }
}

async function sendMessage() {
  if (newMessage !== "") {
    // Emit a chat message event to the server
    try {
      if (role.value > 2) {
        const response = await axios.post(Globals.SERVER_URL + `/chat`, {
          message: newMessage.value,
          user_id,
          ticket_id: 0,
          group_id: role.value,
        });
      } else {
        const response = await axios.post(Globals.SERVER_URL + `/chat`, {
          message: newMessage.value,
          user_id,
          ticket_id: selectedTicket.value,
          group_id: 0,
        });
      }
    } catch (error) {
      console.error(error);
    }
    socket.emit("chatMessage", {
      user_id: user_id,
      message: newMessage.value,
      ticket_id: selectedTicket.value,
      group_id: role.value > 2 ? role.value : 0,
    });

    // Add the message to the local chatMessages array immediately for a smoother user experience
    chatMessages.value.push({
      message: newMessage.value,
    });

    newMessage.value = "";
  }
}
</script>

<template>
  <span v-if="role == 1">
    <div v-if="tickets.length > 0">
      <h1>Chat</h1>
      <div v-for="(message, index) in chatMessages" :key="index">
        <Message :text="message.message" />
      </div>
      <input
        style="width: 90%"
        v-model="newMessage"
        @keyup.enter="sendMessage"
        placeholder="Type a message..."
      />
      <button @click="sendMessage">Send</button>
    </div>
    <div v-else>
      <div class="login">
        <h2 style="color: black">Generate a ticket:</h2>
        <input type="text" v-model="title" placeholder="Subject" /><br />
        <input
          type="text"
          v-model="description"
          placeholder="description"
        /><br />
        <button @click="insertTicket">Generate</button>
      </div>
    </div>
  </span>
  <span v-else-if="role == 2">
    <h1>Chat</h1>
    <span style="display: flex">
      <div style="width: 20%">
        <div v-for="(ticket, index) in ticketList" :key="index">
          <p @click="getChat(ticket?.id)">{{ ticket?.title }}</p>
        </div>
      </div>
      <div style="width: 80%">
        <div v-for="(message, index) in chatMessages" :key="index">
          <Message :text="message.message" />
        </div>
        <input
          style="width: 90%"
          v-model="newMessage"
          @keyup.enter="sendMessage"
          placeholder="Type a message..."
        />
        <button @click="sendMessage">Send</button>
      </div>
    </span>
  </span>
  <span v-else-if="role == 3">
    <h1>Chat</h1>
    <div v-for="(message, index) in chatMessages" :key="index">
      <Message :text="message.message" />
    </div>
    <input
      style="width: 90%"
      v-model="newMessage"
      @keyup.enter="sendMessage"
      placeholder="Type a message..."
    />
    <button @click="sendMessage">Send</button>
  </span>
</template>
<style></style>
