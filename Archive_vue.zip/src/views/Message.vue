<!-- Message.vue -->
<template>
    <div>{{ text }}</div>
  </template>
  
  <script>
  export default {
    props: {
      text: String,
    }
    // ... other component options
  };
  </script>
  